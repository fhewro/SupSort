from .bingo_sort import bingo
